package com.techm.oar.controllers;
import com.techm.oar.beans.Login;
import com.techm.oar.serviceFactory.ServiceFactory;
import com.techm.oar.services.LoginService;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.RequestDispatcher;
public class LoginServlet extends HttpServlet
{
   	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
	{
        int check=0;
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        RequestDispatcher rd = null;
        try 
        {
            String userName=request.getParameter("username");
            String pwd=request.getParameter("password");
            System.out.println(userName);
            System.out.println(pwd);
            Login login=new Login();
            login.setUserName(userName);
            login.setPassword(pwd);
            LoginService loginservice=ServiceFactory.getLoginService();
            check=loginservice.validateUser(login);
            System.out.println(check);
            if(check==1)
            {
            	request.getRequestDispatcher("FlightDetails.jsp").forward(request,response);
                
            }
            if(check==0)
            {
            	request.getRequestDispatcher("loginPage.jsp").forward(request,response);
            }
         } 
        finally { 
            out.close();
        }
     } 

   

   
    
    public String getServletInfo()
    {
        return "Short description";
    }
    
}
