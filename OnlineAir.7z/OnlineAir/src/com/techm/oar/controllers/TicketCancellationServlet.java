package com.techm.oar.controllers;
import com.techm.oar.beans.TicketCancellation;
import com.techm.oar.serviceFactory.ServiceFactory;
import com.techm.oar.services.TicketCancellationService;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class TicketCancellationServlet extends HttpServlet 
{
   	private static final long serialVersionUID = 1L;
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        int check=0;
        System.out.println("djhb");
        RequestDispatcher rd=null;
        try {
            int regId=Integer.parseInt(request.getParameter("registrationID"));
            TicketCancellation cancel=new TicketCancellation();
            cancel.setRegistrationID(regId);
            TicketCancellationService ticCan=ServiceFactory.getTicketCancellationService();
            check=ticCan.cancelTicket(cancel);
            
            if(check==1)
            {
                request.getRequestDispatcher("cancel.jsp").forward(request, response);
                
            }
            if(check==0){
                request.getRequestDispatcher("ticketcancellation.jsp").forward(request, response);
            }
        } finally { 
            out.close();
        }
    }    
    public String getServletInfo() 
    {
        return "Short description";
    }
    
}
