/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.techm.oar.controllers;

import com.techm.oar.beans.TicketBooking;
import com.techm.oar.serviceFactory.ServiceFactory;
import com.techm.oar.services.TicketBookingService;
import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author mslceltp997
 */
public class TicketBookingServlet extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
//        int count=0;

        try {
            String name = request.getParameter("name");
            System.out.println(name);
            String gender = request.getParameter("gender");
            String agency = request.getParameter("agency");
            String trip = request.getParameter("trip");
            String source = request.getParameter("source");
            String destination = request.getParameter("destination");
            int noOfTickets = Integer.parseInt(request.getParameter("numberOfTickets"));
            long mobileNo = Long.parseLong(request.getParameter("mobileNumber"));
            int regId = Integer.parseInt(request.getParameter("registrationID"));
            TicketBooking booking = new TicketBooking();
            booking.setName(name);
            booking.setGender(gender);
            booking.setAgency(agency);
            booking.setTrip(trip);
            booking.setSource(source);
            booking.setDestination(destination);
            booking.setMobileNumber(mobileNo);
            booking.setNumberOfTickets(noOfTickets);
            booking.setRegistrationID(regId);
            TicketBookingService ticSer = ServiceFactory.getTicketBookingService();
            int count = ticSer.bookTicket(booking);
            if (count == 1) {
                request.getRequestDispatcher("viewdetails.jsp").forward(request, response);
            }
//            if (count == 0) {
//                request.getRequestDispatcher("homePage.jsp").forward(request, response);
//            }
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
