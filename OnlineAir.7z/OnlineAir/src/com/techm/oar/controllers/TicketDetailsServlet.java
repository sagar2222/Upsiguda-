/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.controllers;

import com.techm.oar.serviceFactory.ServiceFactory;
import com.techm.oar.services.TicketDetailsService;
import java.io.*;
import java.net.*;

import java.sql.ResultSet;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author mslceltp997
 */
public class TicketDetailsServlet extends HttpServlet {
   
    /** 
    * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        ResultSet rs=null;
        try {
            
		TicketDetailsService view = ServiceFactory.getTicketDetailsService();

		/*String name = request.getParameter("name");
		int registrationID = Integer.parseInt(request.getParameter("registrationID"));
		String gender = request.getParameter("gender");
		String agency = request.getParameter("agency");
		String trip = request.getParameter("trip");
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");
		int numberOfTickets = Integer.parseInt(request.getParameter("numberOfTickets"));
		long mobileNumber=Long.parseLong("mobileNumber");*/
		
		


		//beanClassForTicketDetails details= new beanClassForTicketDetails();
		
		
		/*details.setName(name);
		details.setRegistrationID(registrationID);
		details.setGender(gender);
		details.setAgency(agency);
		details.setTrip(trip);
		details.setSource(source);
		details.setDestination(destination);
		details.setNumberOfTickets(numberOfTickets);
		details.setMobileNumber(mobileNumber);
		*/
                rs=view.ticketDetails();
        } finally { 
            out.close();
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
