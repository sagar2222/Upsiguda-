/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.daoFactory;

import com.techm.oar.dao.LoginDao;
import com.techm.oar.dao.LoginDaoImpl;
import com.techm.oar.dao.RegistrationDao;
import com.techm.oar.dao.RegistrationDaoImpl;
import com.techm.oar.dao.TicketBookingDao;
import com.techm.oar.dao.TicketBookingDaoImpl;
import com.techm.oar.dao.TicketCancellationDao;
import com.techm.oar.dao.TicketCancellationDaoImpl;
import com.techm.oar.dao.TicketDetailsDao;
import com.techm.oar.dao.TicketDetailsDaoImpl;

/**
 *
 * @author mslceltp997
 */
public class DAOFactory {
    private DAOFactory(){}
    public static LoginDao getLoginDao(){
        return new LoginDaoImpl();
    }
    public static RegistrationDao getRegistrationDao(){
        return new RegistrationDaoImpl();
    }
    public static TicketBookingDao getTicketBookingDao(){
        return new TicketBookingDaoImpl();
    }
    public static TicketCancellationDao getTicketCancellationDao(){
        return new TicketCancellationDaoImpl();
    }
    public static TicketDetailsDao getTicketDetailsDao(){
        return new TicketDetailsDaoImpl();
    }
}
