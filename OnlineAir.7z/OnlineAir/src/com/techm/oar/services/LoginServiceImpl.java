/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.services;

import com.techm.oar.beans.Login;
import com.techm.oar.dao.LoginDao;
import com.techm.oar.daoFactory.DAOFactory;

/**
 *
 * @author mslceltp997
 */
public class LoginServiceImpl implements LoginService{

    public int validateUser(Login user){
        LoginDao loginDAO=DAOFactory.getLoginDao();
        return loginDAO.validateUser(user);
    }
}


