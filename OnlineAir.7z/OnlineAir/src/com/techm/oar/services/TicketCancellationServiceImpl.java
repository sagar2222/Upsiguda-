package com.techm.oar.services;
import com.techm.oar.beans.TicketCancellation;
import com.techm.oar.dao.TicketCancellationDao;
import com.techm.oar.daoFactory.DAOFactory;
public class TicketCancellationServiceImpl implements TicketCancellationService{

    public int cancelTicket(TicketCancellation cancel)
    {
        TicketCancellationDao ticketCancellationDAO=DAOFactory.getTicketCancellationDao();
        return ticketCancellationDAO.cancelTicket(cancel);
    }
    
}
