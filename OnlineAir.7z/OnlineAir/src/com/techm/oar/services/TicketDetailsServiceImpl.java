/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.services;

import com.techm.oar.dao.TicketDetailsDao;
import com.techm.oar.daoFactory.DAOFactory;
import java.sql.ResultSet;

/**
 *
 * @author mslceltp997
 */
public class TicketDetailsServiceImpl implements TicketDetailsService{

    public ResultSet ticketDetails() {
        TicketDetailsDao ticketsDetailsDAO=DAOFactory.getTicketDetailsDao();
        return ticketsDetailsDAO.ticketDetails();
    }

}
