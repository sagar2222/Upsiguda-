/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.dao;

import com.techm.oar.beans.RegistrationPage;
import com.techm.oar.utils.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author mslceltp997
 */
public class RegistrationDaoImpl implements RegistrationDao{

    public int registerUser(RegistrationPage user) 
    {
        int value=0;
        Connection con=null;
        PreparedStatement pst=null;
        String userName = user.getUsername();
	String gender = user.getGender();
	String address= user.getAddress();
        String bankName=user.getBankName();
	String dateOfBirth=user.getDateOfBirth();
	String bankAccountNo=user.getBankAccountNo();
        String password=user.getPassword();
	String panNumber=user.getPanNo();
	String bankPrivilegeCustomerNumber=user.getBankPrivilegeCustomerNumber();
	long mobileNo=user.getMobileNo();
        try{
            con=DBUtil.getConnection();
            pst=con.prepareStatement("insert into user_detsails1 values(?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1,userName);
            pst.setString(2, gender);
            pst.setString(3,dateOfBirth);
            pst.setString(4, panNumber);
            pst.setString(5,bankAccountNo);
            pst.setString(6,bankName);
            pst.setString(7,address);
            pst.setLong(8, mobileNo);
            pst.setString(9,bankPrivilegeCustomerNumber);
            pst.setString(10,password);
            value=pst.executeUpdate();
        }catch(SQLException se){
            se.printStackTrace();
        }
        return value;
    }
    
}
