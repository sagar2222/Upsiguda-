/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.dao;

import com.techm.oar.beans.TicketCancellation;
import com.techm.oar.utils.DBUtil;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author mslceltp997
 */
public class TicketCancellationDaoImpl implements TicketCancellationDao{

    public int cancelTicket(TicketCancellation cancel) {
        int check=0;
        Connection con=null;
        Statement st=null;
        ResultSet rs;
        int registrationId=cancel.getRegistrationID();
        System.out.println(registrationId);
        try{
            con=DBUtil.getConnection();
            st=con.createStatement();
            rs=st.executeQuery("select * ticket_details1 where registrationID="+registrationId);
            System.out.println("no.of deleted details....."+check);
        }
        catch(SQLException se)
        {
            se.printStackTrace();
        }
        return check;
    }
}
