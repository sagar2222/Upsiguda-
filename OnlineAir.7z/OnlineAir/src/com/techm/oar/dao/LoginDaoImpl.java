/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.dao;
import com.techm.oar.beans.Login;
import com.techm.oar.utils.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author mslceltp997
 */
public class LoginDaoImpl implements LoginDao{

    public int validateUser(Login user) {
        int flag=0;
        Connection con=null;
        try{
            con=DBUtil.getConnection();
            
            PreparedStatement pst=con.prepareStatement("select * from user_details1 where username=? and password=?");
            pst.setString(1,user.getUserName());
            pst.setString(2,user.getPassword());
            
           System.out.println(user.getUserName());
           System.out.println(user.getPassword());
           
         
      
            ResultSet rs=pst.executeQuery();
            //System.out.println(rs.next());
            while(rs.next())
            {
            	flag=1;
            }
            if(flag==0)
            {
            	flag=0;
            }
        }
        catch(SQLException se)
        {
            se.printStackTrace();
        }
        DBUtil.closeConnection(con);
        System.out.println(flag);
        return flag;
    }

}
