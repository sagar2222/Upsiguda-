/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.techm.oar.beans;

/**
 *
 * @author mslceltp997
 */
public class TicketCancellation {
        private int registrationID;

public int getRegistrationID() {
	return registrationID;
    }

public void setRegistrationID(int registrationID) {
	this.registrationID = registrationID;
	System.out.println(registrationID);
    }
}
